# Index

1. [case](Guide.md)
2. [case anchor](guide.md#getting-started)
3. [ref link][r1]
4. [ref broken][r2]
5. [angle](<with space/inner.md>)
6. [pct](with%20space/inner.md)
7. [titled](guide.md "A title")
8. ![img](missing.png)
9. <a href="gone.md">html</a>
10. [folder](sub/)
11. [up and back](../docs/guide.md)
12. [bad anchor case](guide.md#Getting-Started)

[r1]: guide.md
[r2]: nowhere.md

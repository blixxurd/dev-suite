# B

1. [dup1](a.md#repeat-1)
2. [dup2](a.md#repeat-2)
3. [amp](a.md#setup--run)
4. [setext](a.md#setext-heading)
5. [trail](a.md#trailing-hashes)
6. [html id](a.md#custom)
7. [codeh](a.md#code-in-heading)
8. [dir no slash](sub)
9. [query](a.md?plain=1#title)
10. `[in code](gone1.md)`
11. [empty]()
12. [self](#b)
13. [self bad](#nope)
14. [multi
line](gone2.md)

~~~
[fenced tilde](gone3.md)
~~~

    [indented code](gone4.md)

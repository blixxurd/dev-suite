---
title: "[front](gone-front.md)"
---
# C

1. [hidden](.github/CONTRIBUTING.md)
2. [dot slash](./c.md)
3. [empty frag](c.md#)
4. [upper ext](notes/UPPER.MD)
5. [md ext](notes/long.markdown)
6. [abs](/c.md)
7. [mail](mailto:a@example.com)
8. [web](https://example.invalid/x)
9. ![ref img][i1]

[i1]: gone-img.png
